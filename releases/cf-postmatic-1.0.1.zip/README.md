![Banner](https://calderawp.com/wp-content/uploads/2015/08/cf-postmatic-banner.png)

Postmatic For Caldera Forms
===========================

Add Postmatic site subscriptions to your WordPress forms, using [Caldera Forms](https://calderawp.com/downloads/caldera-forms/).

This plugin is a free plugin by [CalderaWP](https://CalderaWP.com).

* Requires [Postmatic](https://gopostmatic.com/)

Learn more at [https://calderawp.com/downloads/postmatic-for-caldera-forms/](https://calderawp.com/downloads/postmatic-for-caldera-forms/)

### License & Copyright
* Copyright 2015 Josh Pollock for CalderaWP LLC.

* Licensed under the terms of the [GNU General Public License version 2](http://www.gnu.org/licenses/gpl-2.0.html) or later.

* Please share with your neighbor.

